Curso: desarrollador frontend
Clase: 2
Version: 1.0
-
Temas a ejercitar
  eventos y manipulación DOM
  onblur + classList
  onchange + classList
  captcha client side
-
Autor: sergio.minutoli@educacionit.com

--
Laboratorio 1: validar campo repetir email
  Armar una función que valide que el campo email y repetir email tengan el mismo valor
  Ejecutar la validación al salir del campo “repetir email”
  En caso de ser correcto, asignar la clase OK
  En caso de no ser correcto, asignar la clase ERROR

Laboratorio 2: selector de opciones
  Esconder las descripciones de habitaciones
  Detectar el evento change del selector de habitación
  Mostrar la descripción correspondiente a la habitación seleccionada

Laboratorio 3: generar un captcha clientside
  Generar una pregunta matemática azarosa en base a un Array
  Armar una función que valide que la respuesta ingresada corresponda con la respuesta matemática
  Al momento de salir del campo de respuesta, validar con la función armada
  Si la respuesta es correcta, asignar la clase OK al campo
  Si la respuesta es errónea, asignar la clase ERROR al campo e impedir que se envíe el formulario
